package com.mycompany.virtualeventmanagement

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
